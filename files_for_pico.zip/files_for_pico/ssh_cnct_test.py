import paramiko
import paramiko.ssh_exception
import socket

class ssh_access_test:
        def __init__(self, host, username, password):
                self.host=host
                self.username=username
                self.password=password

        def ssh_test(self):
            try:
                host=self.host
                username=self.username
                password=self.password
                ssh = paramiko.SSHClient()
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh.connect(host, username=username, password=password)
                ssh.close()
                access_status="PASS"
                return access_status
            #Captures authentication failure
            #For bad login
            except paramiko.AuthenticationException:
                access_status="LoginFAIL"
                return access_status
            #If server is down
            except paramiko.SSHException as sshException:
                #print(f"Unable to establish SSH connection: {sshException}")
                access_status="NetworkFAIL"
                return access_status
            #Works when network cannot be reached.
            except Exception as cl_access_status:
                #access_status=(str(cl_access_status))
                access_status="NetworkFAIL"
                return access_status
            
    

            