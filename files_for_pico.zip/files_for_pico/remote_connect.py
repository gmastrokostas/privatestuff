import paramiko
import paramiko.ssh_exception
import socket

class remote_scripts:
    def __init__(self, host, username, password):
        self.host=host  
        self.username=username
        self.password=password

    def filesystem_checks(self):    
       try:             
            host=self.host
            username=self.username
            password=self.password
            command = "python -"
            client=paramiko.client.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(host, username=username, password=password, timeout=5)
#SFTP Client for Filesystem check "2_fs_check.py"
            fs_commands=['/usr/bin/chmod +x /var/tmp/2_fs_checks',
          '/var/tmp/2_fs_checks']

            sftp_client = client.open_sftp()
            for servers in host:
                sftp_client.put('dist/2_fs_checks', '/var/tmp/2_fs_checks')        
    
            for lines in fs_commands:
                stdin, stdout, stderr = client.exec_command(lines)
                fs_output = stdout.read().decode()
            sftp_client.remove('/var/tmp/2_fs_checks')
    
            client.close()
            return fs_output
       
       except (paramiko.SSHException, socket.timeout) as paramiko_error:
            print(paramiko_error)


    def network_checks(self):
       try:             
            host=self.host
            username=self.username
            password=self.password
            command = "python -"
            client=paramiko.client.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(host, username=username, password=password, timeout=5)
#SFTP Client for Filesystem check "2_fs_check.py"
            net_commands=['/usr/bin/chmod +x /var/tmp/network_checks',
          '/var/tmp/network_checks']

            sftp_client = client.open_sftp()
            for servers in host:
                sftp_client.put('dist/network_checks', '/var/tmp/network_checks')        
    
            for lines in net_commands:
                stdin, stdout, stderr = client.exec_command(lines)
                net_output = stdout.read().decode()
            sftp_client.remove('/var/tmp/network_checks')
    
            client.close()
            return net_output
       
       except (paramiko.SSHException, socket.timeout) as paramiko_error:
            print(paramiko_error)
        


    def gen_checks(self):    
       try:             
            host=self.host
            username=self.username
            password=self.password
            command = "python -"
    
            client=paramiko.client.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(host, username=username, password=password, timeout=5)
#SFTP Client for Filesystem check "2_fs_check.py"
            gen_commands=['/usr/bin/chmod +x /var/tmp/general_checks',
          '/var/tmp/general_checks']

            sftp_client = client.open_sftp()
            for servers in host:
                sftp_client.put('dist/general_checks', '/var/tmp/general_checks')        
    
            for lines in gen_commands:
                stdin, stdout, stderr = client.exec_command(lines)
                gen_output = stdout.read().decode()
            sftp_client.remove('/var/tmp/general_checks')
    
            client.close()
            return gen_output
       
       except (paramiko.SSHException, socket.timeout) as paramiko_error:
            print(paramiko_error)

#x=remote_scripts()
#fs_results=x.filesystem_checks()
#print(fs_results)
