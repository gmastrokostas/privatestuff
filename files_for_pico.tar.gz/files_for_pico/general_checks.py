from pathlib import Path
import subprocess
import os
from sys import exit


class general_checks_sct6:


####TIMEZONE CHECKS FOR OS
    def time_zone_check(self):
    #Find Timezone
        timezone_link="/etc/localtime"
        resolved_path=Path(timezone_link).resolve()

        resolved_path_string=(str(resolved_path))
        server_timezone=resolved_path_string.split("/")[5]
        #print(server_timezone, "HAHAHA")
        if "New_York" in server_timezone:
            zone="TZ:NY"
            return zone
##################################################################################################################################
    def systemctl_service_checks(self):
        systemctl_command = "systemctl list-units --failed"
        service_checks = subprocess.Popen(systemctl_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, shell=True)
        raw_output=[]
        for line in service_checks.stdout:
            status_service=line.split()
            if  "fail" in line:
                systemctl_status=(f"FAILED: {status_service[1]}")
                raw_output.append(systemctl_status)
            elif "warning" in line:
                systemctl_status=(f"WRN: {status_service[1]}")
                raw_output.append(systemctl_status)
            
        if (len(raw_output))!=0:
            #print(raw_output)
            systemctl_status=raw_output
        else:
            #print(raw_output)
            systemctl_status="PASS"
        return systemctl_status
################################################################################################################################

    def rsyslog_check(self):
        #will crate an output for the status of the journalctl service
        #we will capture it and then append the stdout in 
        systemctl_command = "systemctl  status rsyslog.service"
        rsyslog_checks = subprocess.Popen(systemctl_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, shell=True)
        command_output_list_1=[]
        for line in rsyslog_checks.stdout:
            x=(line.split())
            command_output_list_1.append(x)

        journal_dir=os.path.exists("/var/log/journal")
        if journal_dir == True:
            dir_check="PASS:"
        elif journal_dir == False:
            dir_check="journal dir missing"

        if (len(command_output_list_1) == 0):
            installedorno="service not installed"
        elif (len(command_output_list_1) > 0):
            installedorno="PASS:"

        if "PASS" in installedorno:
            rsyslog_status=command_output_list_1[2]
      
        if "dead" in rsyslog_status[2] or "failed" in rsyslog_status[1] :
            runningorno="srvc not running"
        elif "running" in rsyslog_status[2]:
            runningorno="PASS:"

        x=(dir_check, installedorno, runningorno)

        for lols in x:
            if "PASS" not in lols:
                result=(f"FAIL: {lols}")
                #print(result)
            elif "PASS" in dir_check and "PASS" in installedorno and "PASS" in runningorno:
                result="PASS"
        return result



###################################
#We are calling the methods here. #
###################################
gen_check_results_list=[]
###################################
####CALLING time_zone_check method 
tzcheck = general_checks_sct6()
tzchecking=tzcheck.time_zone_check()
#print(tzchecking)
####################################
####CALLING systemctl_service_checks method
systemctchck=general_checks_sct6()
sysctl_result=systemctchck.systemctl_service_checks()
#print(sysctl_result)
###################################
####CALLING journalctl_check method
journalctl=general_checks_sct6()
journct_result=journalctl.rsyslog_check()
#print(journct_result)

gen_check_results_list.append(tzchecking)
gen_check_results_list.append(sysctl_result)
gen_check_results_list.append(journct_result)
print(gen_check_results_list)

#####print(tzchecking, sysctl_result)

#gen_check_results_list.append(tzchecking)
#gen_check_results_list.append(sysctl_result)
#print(gen_check_results_list)