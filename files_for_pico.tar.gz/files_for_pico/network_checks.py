import netifaces
import subprocess
import re
import os
import os.path

class network_checks_sect6:
    
  def ping_test(self):
    inteface_info=[]
    gateway_IPS=[]
    ping_results_list=[]
    #This gets the ifnames and the gateways only
    #in the form of a dictionary.
    ifaces=netifaces.gateways().items()
    #print(ifaces)

    #STEP 1- We want to have in an easy to access format (ifname, gw, True/False)
    #---
    #We take the dictionary from above and
    #we combine in an easy format so we can have a list
    #[(ifname, gateway, True/False)]
    for items1 in ifaces:
      #print(items1[1])
      for items2 in items1[1]:
        inteface_info.append(items2)
    inteface_info.pop(0)
    #print(inteface_info)

    #We are isolating the GWs here
    for ip in inteface_info:
      gateway_IPS.append(ip[0])
    
    #Use this specific line if you want to test your code
    #Disable the above for loop to do that.
    #gateway_IPS=["192.168.0.1", "192.168.10.10", "192.168.0.234"]

    for ping_check in gateway_IPS:
      try:
        pinger = subprocess.run(["ping", "-c", "2", "-w", "3", ping_check], capture_output=True, text=True, check=True)
        ping_result=(f"PASS: {ping_check}")
        #print(ping_result)
        
      except Exception as e:
        ping_result=(f"PING:FAIL Cant ping {ping_check}")
        #print(ping_result)
        #if (ping_result !=""):
        #    print(ping_result)
      ping_results_list.append(ping_result)
      #print(ping_results_list)
    str_ping_results=(str(ping_results_list))
    #search_results=re.findall("FAIL", str_ping_results)
    if "FAIL" not in str_ping_results:
      ping_results_list=["PING:PASS"]
    else:
      pass    
    return ping_results_list
########################################################
  def link_check(self):
    link_results=[]
    sys_net_path="/sys/class/net/"
    operstate_file="/operstate"
    interfaces_found=os.listdir(sys_net_path)
    for ifs in interfaces_found:
        path_1=sys_net_path+ifs
        if os.path.islink(path_1) and "lo" not in ifs:
            full_path=(sys_net_path+ifs+operstate_file)
            #print(full_path)
            file_o=open(full_path, "r")
            read_if_state=(file_o.read())
            if_state=(ifs,  read_if_state)
            ph_state_list=(list(if_state))
            state_string=(str(ph_state_list))
            if "down" in state_string:
               #print(state_string)
                link_status=("LINK:DOWN", ph_state_list[0])
                link_results.append(link_status)

            else:
                #link_status=["LINK: PASS"]
                link_results=["LINK: PASS"]
    
    return link_results
  
########################################################
  def nmcli_checks(self):
        systemctl_command = "nmcli device status"
        mcli_checks = subprocess.Popen(systemctl_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, shell=True)
        raw_output=[]
        for line in mcli_checks.stdout:
            status_device=line.split()
            if  "disconnected" in line:
                nmcli_status=(f"NMCLI:FAIL {status_device[0]} {status_device[1]} {status_device[2]}")
                raw_output.append(nmcli_status)
            elif "warning" in line:
                nmcli_status=(f"WRN {status_device[1]}")
                raw_output.append(nmcli_status)
            
        if (len(raw_output))!=0:
            #print(raw_output)
            nmcli_status=raw_output
        else:
            #print(raw_output)
            nmcli_status="PASS"
        return nmcli_status
########################################################################################################    
#################################
net_checks=network_checks_sect6()
#################################
ping_output=net_checks.ping_test()
#print("PING", ping_output)
#
ph_link=net_checks.link_check()
ph_link=str(ph_link)

#if "PASS" in ph_link:
   #print("LINK:PASS")
#   ph_link="LINK:PASS"

#
nmcli_output=net_checks.nmcli_checks()
#print(nmcli_output)


ping_output=str(ping_output)
ph_link=str(ph_link)
nmcli_output=str(nmcli_output)


if all("FAIL" not in output for output in (ping_output, ph_link, nmcli_output)):
    print(" PASS")
else:
    bad_puppies = [var for var in (ping_output, ph_link, nmcli_output) if "FAIL" in var]

print(bad_puppies)
#failed_variables=str(failed_variables)
#x=failed_variables.split()
#print(x)