#Define a list with default directories
#Check if / is in LVM
import os, psutil
class pto_file_system_checks_sct6:
    def __init__(self):
        #var contains info for all mounted partitions
        self.part_info=psutil.disk_partitions()
        #Finds where "/" sits on. Doesnt matter if its LVM or not
        self.rootfs = [fs for fs in self.part_info if fs[1] == "/"]
        
    def find_lvm_and_non_lvm_prt(self):
        #Finds all dev in lvm and dev not in lvm
        #We collect this data because we will need it for 
        #the  "find_none_standard_mapper" method
        #if "mapper" in /dev/.... then its an lvm.
        #Examples of output
        #device='/dev/mapper/rl-root', mountpoint='/'...etc.)
        #device='/dev/mapper/nme01p1,  mountpoint='/boot'....etc.)
        self.all_lvm_prts=[]
        self.all_non_lvm_prts=[]
        for lvm_match in self.part_info:
            if "mapper" in lvm_match[0]:
                self.all_lvm_prts.append(lvm_match)
                #print(self.all_lvm_prts)
            if "mapper" not in lvm_match[0]:
                self.all_non_lvm_prts.append(lvm_match)
                #print(self.all_non_lvm_prts)

    #This method is used strickly to see if "/" sits in lvm or not.
    def find_root_lvm(self):
        for matchfs in self.rootfs:
            self.root_device=matchfs[0]
            self.root_mount=matchfs[1]
            #print(self.root_device)
            #print(self.root_mount)
        if "mapper"  in self.root_device:
            self.lvm_root=self.root_device
            self.root_mount=self.root_mount
            self.root_lvm_status="PASS: root in LVM | "
        elif "mapper" not in self.root_device:
            self.root_lvm_status="FAIL: root not in lvm | "
        #print(self.root_lvm_status)
        return self.root_lvm_status  
    
    def find_none_standard_mapper(self):
        list_of_all_root_lvm=[]
        list_of_all_root_lvm_mounts=[]
        set_of_standard_mounts={'/','/var', '/boot', '/dev', '/etc', '/home',
                         '/lib', '/usr', '/lib64', '/media', '/mnt',
                         '/opt', '/proc', '/root', '/run', '/srv', '/sys',
                         '/tmp', '/usr', '/var'}
        
        #We want to isolate the VG name of where the "/" sits on
        #We already have the full path of the lvm where "/" sits on (lvm_root)
        # which is /dev/mapper/rl-root
        # we split for / then for - and then we isolate the VG name which is rl.
        split_fullpath=self.lvm_root.split("/")
        split_root_name=split_fullpath[3]
        vg_name=split_root_name.split("-")[0]
        
        #Here we split all the lvm_parts we captured from before
        #Here we will capture all partitions that have the same
        #name as the VG where ("/") sits on. See above.
        
        #We then print item 3 (rl-home)
        #We then split that with "-" and grab the first element ("rl")
        for x in self.all_lvm_prts:
            #print(x[0].split("/")[3], x[1], "HAHAHA")
            #From all_lvm_prts we take the [0] element (,/dev/mapper/rl-home)
            #We split it using "/". We take the [3] element which is ('rl-home')
            #We then split with "-" and we end up with 'rl, home'
            #x[1] is the mount points from all_lvm_parts
            #We end up with  ['rl', 'home'], '/home')
            isol_1=(x[0].split("/")[3].split("-"), x[1])
            #Here we take rl, /home
            isol_2=isol_1[0][0], isol_1[1]
            #Here we convert the tulip into a list
            isol_3=list(isol_2)
            if vg_name == isol_3[0]:
                list_of_all_root_lvm.append(isol_3)
        for x in list_of_all_root_lvm:
            list_of_all_root_lvm_mounts.append(x[1])
        #Use the list_of_all_root_lvm_mounts to isolate [1] mount point
        #Turn it into a set and compare it with "set_of_standard_mounts"
        #convert the list into a set
        set_of_all_root_lvm_mounts=(set(list_of_all_root_lvm_mounts))
        
        diff_result=set_of_all_root_lvm_mounts.difference(set_of_standard_mounts)
        if len(diff_result) != 0:
            self.standard_root_lvms=("FAIL: ",diff_result)
            #print(self.standard_root_lvms)
        else:
            self.standard_root_lvms="PASS STRUCT OK |"
            #print(self.standard_root_lvms)
        return self.standard_root_lvms
        

    def find_available_space(self):
        for i in self.all_lvm_prts:
            mount_points=i[1]
            used_space=psutil.disk_usage(mount_points)
            #print(used_space)
            free_space=100-used_space[3]
            #print(mount_points, free_space)
            #print(mount_points, free_space)
            if free_space < 15.0:
                #print("FAIL", mount_points, free_space)
                self.fs_size_status=("FAIL", mount_points, ">85%")
            else:
                #print("PASS", mount_points, free_space)
                self.fs_size_status=("PASS: Freespc>85%")
        #print(self.fs_size_status)
        return self.fs_size_status
    
x=pto_file_system_checks_sct6()
root_lvm=x.find_root_lvm()
if "FAIL" in root_lvm:
    results="FAIL: ROOT NOT IN LVMS"
    print(results)
    quit();
x.find_lvm_and_non_lvm_prt()
fs_strctr=x.find_none_standard_mapper()
fs_space=x.find_available_space()

#results=[root_lvm, fs_strctr, fs_space]
#This is the output captured by paramiko
if "PASS" in root_lvm and "PASS" in fs_strctr and "PASS" in fs_space:
    print("PASS")
else:
    print(root_lvm, fs_strctr, fs_space)



#for i in results:
#    if "FAIL" in i[0]:
#        print(i)
#print(results[1])
#else:
#    print(root_lvm, fs_strctr, fs_space)
#print(root_lvm, fs_strctr, fs_space)

#if "FAIL" in root_lvm:
#    print("PTO FAILED STOP")
#else:
    #print(root_lvm, fs_strctr, fs_space)
#    print("lol")#fs_strctr)