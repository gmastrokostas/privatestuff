#####################################
#cat script.py | ssh user@server "python -"
#PY files infolved
# - 1_d42_check.py.py
# - 2_fs_checks.py
# - remote_connect.py
# - ssh_cnct_test.py
######SECTION ONE###################
#1)It reads server names from text file
#2)It writes the servers names to the hostname cells on the spreadsheet
import socket
import shutil
from   openpyxl.workbook import Workbook
from   openpyxl import load_workbook
import getpass
import paramiko
import re
#Custom made classes/methods
from   ssh_cnct_test  import ssh_access_test
from   remote_connect import remote_scripts

#from general_checks import general_checks_sct6
#Start with a fresh spreadsheet.
clean_sheet="pto_template.xlsx"
working_sheet="pto_xxx.xlsx"
shutil.copy(clean_sheet, working_sheet)
###

#Load the spreadsheet
server_list=[]
cell_values=[]
#wb=load_workbook('PTO_xxx.xlsx')
wb=load_workbook('pto_xxx.xlsx')
ws=wb.active

#read the hosts we want to PTO and insert them in a list
server_list_names=[]
f_open=open("hostnames_pto.txt", "r")

#Append hostnames from text file into your list
for servernames in f_open:
    server_list_names.append(servernames.strip())
#print(server_list_names)

###########
#Here you call the method exec_scripts.
#But before you do that you need to pass the varialbe to self.host to that method.
#See info[0] below.
##################
#rmt_scrpts=remote_scripts('192.168.0.75')
#fs_results=rmt_scrpts.filesystem_checks()
#print(fs_results)

username=input("Enter your login name: ")
password=getpass.getpass()

servers_found=[]
read_file=open("dump.csv", "r")
base_column_count=4
for x in read_file:
    info=x.split((","))
    var1=info[0]
    info_1=var1.split(("."))
    #REMEMBER: info_1[0] is the hostname !
    if info_1[0] in server_list_names:
        #print(info_1[0], "HAHAHAH")
        base_column_count = base_column_count + 1
        
        #####################################################
        #PTO SECTION 2.*
        #DATA FOR ALL SECTION 2 IS TAKEN BY DUMP.CSV FILE FOR
        #####
        #DATA FOR ROW 12
        D42DeviceEntry = info_1[0]
        servers_found.append(D42DeviceEntry)
        #print(D42DeviceEntry)
        ws.cell(row=12, column=base_column_count, value=D42DeviceEntry)

        #####
        #DATA FOR ROW 14
        D42RackElevation = info[24]
        servers_found.append(D42RackElevation)
        ws.cell(row=14, column=base_column_count, value=D42RackElevation)
        #print(D42RackElevation)
        ##########

        #DATA FOR ROW 16
        D42Customer = info[26]
        servers_found.append(D42Customer)
        ws.cell(row=16, column=base_column_count, value=D42Customer)
        #print(D42Customer)

        #DATA FOR ROW  17
        D42DeviceType = info[3]
        servers_found.append(D42DeviceType)
        ws.cell(row=17, column=base_column_count, value=D42DeviceType)
        #print(D42DeviceType)

        #DATA FOR ROW  18
        D42SupportLevel = info[4]
        servers_found.append(D42SupportLevel)
        ws.cell(row=18, column=base_column_count, value=D42SupportLevel)
        #print(D42SupportLevel)

        #DATA FOR ROW 19
        D42ResponsibleGroup = info[5]
        servers_found.append(D42ResponsibleGroup)
        ws.cell(row=19, column=base_column_count, value=D42ResponsibleGroup)
        #print(D42ResponsibleGroup)

        #DATA FOR ROW 20
        D42BusinessUnit = info[7]
        servers_found.append(D42BusinessUnit)
        ws.cell(row=20, column=base_column_count, value=D42BusinessUnit)
        #print(D42BusinessUnit)

        #DATA FOR ROW 21
        D42Environment = info[8]
        servers_found.append(D42Environment)
        ws.cell(row=21, column=base_column_count, value=D42Environment)
        #print(D42Environment)

        ##############################
        #PTO SECTION 6.* 
        ##############################
        #Do not change the order here we want to be done with
        #data captured outside of paramiko first
        #
        #Linux version
        #Data taken from CSV file
        #Data for row 66 Section 6.4
        D42LinuxVersion = info[18]
        ws.cell(row=66, column=base_column_count, value=D42LinuxVersion)
        #print(D42LinuxVersion)

        #DNS AD
        #Data taken from socket module
        #Data for row 63 Section 6.1
        
        try:
            fwrd_dns_check=socket.gethostbyname(D42DeviceEntry)
            #print(fwrd_dns_check)
            fw_dnsresults="PASS"
        except Exception as err:
            fwrd_dns_check="No A Record"
            #print(fwrd_dns_check)
            fw_dnsresults="FAIL"
        try:
            rvrs_dns=socket.gethostbyaddr(fwrd_dns_check)
            rvrs_dns_check=rvrs_dns[0]
            #print(D42DeviceEntry, rvrs_dns)
            rvr_dnsresults="PASS"
        except Exception as err:
            rvrs_dns_check="No PR Record"
            #print(D42DeviceEntry, rvrs_dns_check)
            rvr_dnsresults="FAIL"

        if  fw_dnsresults=="PASS" and rvr_dnsresults=="PASS":
            dns_results="PASS"
            #print(D42DeviceEntry, dns_results)
        elif fw_dnsresults=="FAIL" and rvr_dnsresults=="FAIL":
            dns_results="FAIL DNS"
            #print(D42DeviceEntry, dns_results)
        #    
        #elif fw_dnsresults=="FAIL" and rvr_dnsresults=="PASS" :
        #    dns_results="NO FW RCRD"
        #    print(D42DeviceEntry, dns_results)
        elif fw_dnsresults=="PASS" and rvr_dnsresults=="FAIL":
            dns_results="FAIL PTR RCRD"
            #print(D42DeviceEntry, dns_results)
            fwrd_dns_check=socket.gethostbyname(D42DeviceEntry)
            #print(fwrd_dns_check)
        ws.cell(row=63, column=base_column_count, value=str(dns_results))
        #print(dns_results)

        ##############################
        #PARAMIKO part of section 6
        ##############################
        #Access
        #Data taken from paramiko
        #Data for row 65 section 6.3
        #We first want to get done with SSH checks before we 
        #do the other more complicated remote checks.
        #We keep this keep here so we wont complicate the logic within other
        #classses.
        ssh_test=ssh_access_test(info_1[0], username, password)
        ssh_results=ssh_test.ssh_test()
        ws.cell(row=65, column=base_column_count, value=ssh_results)
        #print(ssh_results)
        if "FAIL" in ssh_results:
            #print("SOL")
            ws.cell(row=76, column=base_column_count, value="N/A")
            ws.cell(row=80, column=base_column_count, value="N/A")
            ws.cell(row=72, column=base_column_count, value="N/A")
            ws.cell(row=73, column=base_column_count, value="N/A")
            ws.cell(row=78, column=base_column_count, value="N/A")
        ############ BUG FOUND - whole things breaks when you enable this.
        #if "FAIL" in dns_results:
        #    ws.cell(row=63, column=base_column_count, value=str(dns_results))


        else:   
        ####FILESYSTEMCHECK PTO Check 6.14 on row 76
            #Passing vars to the paramiko class on remote_connect.py
            rmt_scrpts=remote_scripts(info_1[0], username, password)
            #Calling the Filesystem check method
            fs_results=rmt_scrpts.filesystem_checks()
            ws.cell(row=76, column=base_column_count, value=fs_results)

        ####GENERAL CHECKS PTO Check 6.18 on row 80    
        #####ALL THESE CHECKS ARE LOCATED IN THE "general_checks.py"
            #TIMEZONE RESULTS
            #This is the Datacenter field from the csv file
            D42Datacenter = info[22]
            #print(D42Datacenter)
            #Calling the gen_checks method from remote_scripts
            #It contains several diff results so thats why we split it.
            general_results=rmt_scrpts.gen_checks()
            general_results_parsed=general_results.split(",")
            #print(general_results)
            
            
            ####TIMEZONE PTO CHECK 6.18 row 80
            #We isolate the TIMEZONE results
            #tz_results=general_results.split()[0]
            #tz_results=tz_results.split(":")[1]
            tz_results=general_results_parsed[0]
            tz_results=tz_results.split(":")
            tz_results=tz_results[1]
            ws.cell(row=80, column=base_column_count, value=tz_results)
            print(tz_results)
            
            ####SERVICES PTO CHECK 6.10 ROW 72
            #We isolate the service results
            sysctl_results=general_results_parsed[1]
            #print(general_results_parsed[2])
            sysctl_results=(str(sysctl_results))
            sysctl_results=re.sub('[^a-zA-Z ]+', '', sysctl_results)
            ws.cell(row=72, column=base_column_count, value=sysctl_results)
            print(sysctl_results)

            #SYSLOG PTO CHECK 6.16 ROW 78
            #rsyslog_results=general_results.split()[2:]
            rsyslog_results=general_results_parsed[2]
            rsyslog_results=(str(rsyslog_results))
            ws.cell(row=78, column=base_column_count, value=rsyslog_results)
            #print(rsyslog_results)


            ###############################################################################
            ###NETWORK PTO CHECK 6.11 ROW 73
            ####THESE CHECKS ARE IN network_checks.py
            rmt_scrpts=remote_scripts(info_1[0], username, password)
            net_results=rmt_scrpts.network_checks()
            net_results=re.sub('[^a-zA-Z ]+', '',net_results)
            ws.cell(row=73, column=base_column_count, value=net_results)

        hostnames=servers_found[0]
        for item in servers_found:
            if item:
                c_value="Y"
            else:
                c_value="N"
            cell_values.append(c_value)

        #print(cell_values)
        #print(servers_found)
        servers_found.clear()
        cell_values.clear()
wb.save('pto_xxx.xlsx')